package configs

type Direction int

const (
	North Direction = iota
	East
	South
	West
)

const DirectionLen = 4

type GameConfig struct {
	CostPerMove int
	CostPerTurn int
	GridSize    int
}

var GameConfigInstance = GameConfig{
	CostPerMove: 10,
	CostPerTurn: 5,
	GridSize:    6,
}
