package main

import (
	"Gman/configs"
	"Gman/gman"
	"Gman/gmancontroller"
	"fmt"
)

func main() {
	fmt.Println("Hello, Modules!")
	point := gman.Point{
		X: 2,
		Y: 1,
		D: configs.East,
	}
	gmanInstance := gman.CreateGman(point, 200, configs.GameConfigInstance)
	controller := gmancontroller.CreateController(gmanInstance)

	power := controller.MoveGmanToDestination(4, 3)
	fmt.Println(power)
}
